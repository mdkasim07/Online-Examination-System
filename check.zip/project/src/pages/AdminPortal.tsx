import React, { useState } from 'react';
import { Users, BookOpen, FileText } from 'lucide-react';

export const AdminPortal: React.FC = () => {
  const [activeTab, setActiveTab] = useState('students');

  const stats = [
    { name: 'Total Students', value: '2,345', icon: Users },
    { name: 'Active Courses', value: '48', icon: BookOpen },
    { name: 'Total Exams', value: '156', icon: FileText },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
        
        <div className="mt-8">
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div className="p-6">
              <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
                {stats.map((stat) => (
                  <div
                    key={stat.name}
                    className="px-4 py-5 bg-gray-50 shadow rounded-lg overflow-hidden sm:p-6"
                  >
                    <div className="flex items-center">
                      <div className="flex-shrink-0">
                        <stat.icon className="h-8 w-8 text-indigo-600" />
                      </div>
                      <div className="ml-5 w-0 flex-1">
                        <dl>
                          <dt className="text-sm font-medium text-gray-500 truncate">
                            {stat.name}
                          </dt>
                          <dd className="text-2xl font-semibold text-gray-900">
                            {stat.value}
                          </dd>
                        </dl>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="border-t border-gray-200">
              <div className="px-4 sm:px-6">
                <nav className="-mb-px flex space-x-8">
                  <button
                    onClick={() => setActiveTab('students')}
                    className={`${
                      activeTab === 'students'
                        ? 'border-indigo-500 text-indigo-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                  >
                    Students
                  </button>
                  <button
                    onClick={() => setActiveTab('courses')}
                    className={`${
                      activeTab === 'courses'
                        ? 'border-indigo-500 text-indigo-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                  >
                    Courses
                  </button>
                  <button
                    onClick={() => setActiveTab('exams')}
                    className={`${
                      activeTab === 'exams'
                        ? 'border-indigo-500 text-indigo-600'
                        : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                    } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
                  >
                    Exams
                  </button>
                </nav>
              </div>
            </div>

            <div className="px-4 py-6 sm:px-6">
              {activeTab === 'students' && (
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <h3 className="text-lg font-medium text-gray-900">Student List</h3>
                    <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                      Add Student
                    </button>
                  </div>
                  {/* Add student list table here */}
                </div>
              )}
              {activeTab === 'courses' && (
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <h3 className="text-lg font-medium text-gray-900">Course Management</h3>
                    <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                      Add Course
                    </button>
                  </div>
                  {/* Add course management interface here */}
                </div>
              )}
              {activeTab === 'exams' && (
                <div className="space-y-4">
                  <div className="flex justify-between">
                    <h3 className="text-lg font-medium text-gray-900">Exam Management</h3>
                    <button className="bg-indigo-600 text-white px-4 py-2 rounded-md hover:bg-indigo-700">
                      Create Exam
                    </button>
                  </div>
                  {/* Add exam management interface here */}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};