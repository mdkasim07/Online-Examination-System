import React from 'react';
import { Book, Clock, Award, Calendar } from 'lucide-react';

export const StudentDashboard: React.FC = () => {
  const enrolledCourses = [
    {
      id: '1',
      title: 'Introduction to Computer Science',
      progress: 65,
      nextExam: '2024-03-25',
    },
    {
      id: '2',
      title: 'Web Development Bootcamp',
      progress: 30,
      nextExam: '2024-03-28',
    },
  ];

  const upcomingExams = [
    {
      id: '1',
      title: 'CS Fundamentals Quiz',
      date: '2024-03-25',
      duration: '1 hour',
    },
    {
      id: '2',
      title: 'HTML & CSS Assessment',
      date: '2024-03-28',
      duration: '45 minutes',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="md:flex md:items-center md:justify-between">
          <div className="flex-1 min-w-0">
            <h2 className="text-2xl font-bold leading-7 text-gray-900 sm:text-3xl sm:truncate">
              Welcome back, Student
            </h2>
          </div>
        </div>

        <div className="mt-8 grid gap-8 grid-cols-1 lg:grid-cols-2">
          {/* Enrolled Courses */}
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
                <Book className="h-5 w-5 mr-2 text-indigo-600" />
                Enrolled Courses
              </h3>
              <div className="mt-6 space-y-6">
                {enrolledCourses.map((course) => (
                  <div key={course.id} className="border-t border-gray-200 pt-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <h4 className="text-sm font-medium text-gray-900">{course.title}</h4>
                        <div className="mt-2">
                          <div className="bg-gray-200 rounded-full h-2">
                            <div
                              className="bg-indigo-600 rounded-full h-2"
                              style={{ width: `${course.progress}%` }}
                            />
                          </div>
                          <p className="mt-1 text-sm text-gray-500">{course.progress}% complete</p>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Upcoming Exams */}
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
                <Calendar className="h-5 w-5 mr-2 text-indigo-600" />
                Upcoming Ex ams
              </h3>
              <div className="mt-6 space-y-4">
                {upcomingExams.map((exam) => (
                  <div key={exam.id} className="border-t border-gray-200 pt-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="text-sm font-medium text-gray-900">{exam.title}</h4>
                        <div className="mt-1 flex items-center space-x-4 text-sm text-gray-500">
                          <div className="flex items-center">
                            <Calendar className="h-4 w-4 mr-1" />
                            {exam.date}
                          </div>
                          <div className="flex items-center">
                            <Clock className="h-4 w-4 mr-1" />
                            {exam.duration}
                          </div>
                        </div>
                      </div>
                      <button className="bg-indigo-100 text-indigo-700 px-3 py-1 rounded-md text-sm hover:bg-indigo-200">
                        View Details
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Recent Performance */}
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
                <Award className="h-5 w-5 mr-2 text-indigo-600" />
                Recent Performance
              </h3>
              <div className="mt-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">Average Score</p>
                    <p className="mt-1 text-2xl font-semibold text-indigo-600">85%</p>
                  </div>
                  <div className="bg-gray-50 p-4 rounded-lg">
                    <p className="text-sm text-gray-500">Completed Exams</p>
                    <p className="mt-1 text-2xl font-semibold text-indigo-600">12</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Study Resources */}
          <div className="bg-white shadow rounded-lg">
            <div className="px-4 py-5 sm:p-6">
              <h3 className="text-lg leading-6 font-medium text-gray-900 flex items-center">
                <Book className="h-5 w-5 mr-2 text-indigo-600" />
                Study Resources
              </h3>
              <div className="mt-6 space-y-4">
                <div className="border-t border-gray-200 pt-4">
                  <a href="#" className="block hover:bg-gray-50">
                    <div className="flex items-center">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">Course Materials</p>
                        <p className="mt-1 text-sm text-gray-500">Access lecture notes and slides</p>
                      </div>
                      <div className="ml-4">
                        <svg className="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </div>
                  </a>
                </div>
                <div className="border-t border-gray-200 pt-4">
                  <a href="#" className="block hover:bg-gray-50">
                    <div className="flex items-center">
                      <div className="flex-1">
                        <p className="text-sm font-medium text-gray-900">Practice Tests</p>
                        <p className="mt-1 text-sm text-gray-500">Prepare with sample questions</p>
                      </div>
                      <div className="ml-4">
                        <svg className="h-5 w-5 text-gray-400" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                        </svg>
                      </div>
                    </div>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};