import React from 'react';
import { Link } from 'react-router-dom';
import { Clock, Book } from 'lucide-react';

const courses = [
  {
    id: '1',
    title: 'Introduction to Computer Science',
    description: 'Learn the fundamentals of computer science and programming.',
    imageUrl: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97',
    duration: '8 weeks',
    lessons: 12,
  },
  {
    id: '2',
    title: 'Web Development Bootcamp',
    description: 'Master modern web development technologies and frameworks.',
    imageUrl: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085',
    duration: '12 weeks',
    lessons: 24,
  },
  {
    id: '3',
    title: 'Data Science Essentials',
    description: 'Explore data analysis, visualization, and machine learning basics.',
    imageUrl: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71',
    duration: '10 weeks',
    lessons: 18,
  },
];

export const Courses: React.FC = () => {
  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">
            Available Courses
          </h2>
          <p className="mt-3 max-w-2xl mx-auto text-xl text-gray-500 sm:mt-4">
            Choose from our selection of comprehensive courses
          </p>
        </div>

        <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {courses.map((course) => (
            <div
              key={course.id}
              className="flex flex-col rounded-lg shadow-lg overflow-hidden bg-white"
            >
              <div className="flex-shrink-0">
                <img
                  className="h-48 w-full object-cover"
                  src={course.imageUrl}
                  alt={course.title}
                />
              </div>
              <div className="flex-1 p-6 flex flex-col justify-between">
                <div className="flex-1">
                  <h3 className="text-xl font-semibold text-gray-900">{course.title}</h3>
                  <p className="mt-3 text-base text-gray-500">{course.description}</p>
                </div>
                <div className="mt-6">
                  <div className="flex items-center text-sm text-gray-500 space-x-4">
                    <div className="flex items-center">
                      <Clock className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                      <span>{course.duration}</span>
                    </div>
                    <div className="flex items-center">
                      <Book className="flex-shrink-0 mr-1.5 h-5 w-5 text-gray-400" />
                      <span>{course.lessons} lessons</span>
                    </div>
                  </div>
                  <div className="mt-4">
                    <Link
                      to={`/courses/${course.id}`}
                      className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
                    >
                      View Course
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};