export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
}

export interface Course {
  id: string;
  title: string;
  description: string;
  imageUrl: string;
}

export interface Exam {
  id: string;
  courseId: string;
  title: string;
  duration: number;
  totalMarks: number;
}